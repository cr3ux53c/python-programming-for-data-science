for _ in range(10):
    print("Hello, World")
