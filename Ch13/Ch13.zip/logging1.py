import logging

logging.debug("틀렸잖아!")
logging.info("확인해!")
logging.warning("조심해!")
logging.error("에러 났어!!!")
logging.critical ("망했다….")
